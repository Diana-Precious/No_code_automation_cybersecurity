import React from 'react';
import { Shield, Zap, Lock, Workflow, Database, Cloud, Terminal, Eye } from 'lucide-react';

const Skills = () => {
  const automationSkills = [
    {
      icon: Workflow,
      title: 'Process Automation',
      description: 'Design and implement complex workflow automations',
      level: 95
    },
    {
      icon: Database,
      title: 'Data Integration',
      description: 'Connect and synchronize data across platforms',
      level: 90
    },
    {
      icon: Zap,
      title: 'API Orchestration',
      description: 'Seamlessly integrate APIs and web services',
      level: 88
    },
    {
      icon: Cloud,
      title: 'Cloud Automation',
      description: 'Automate cloud infrastructure and deployments',
      level: 85
    }
  ];

  const securitySkills = [
    {
      icon: Shield,
      title: 'Security Architecture',
      description: 'Design secure automation frameworks',
      level: 92
    },
    {
      icon: Lock,
      title: 'Access Control',
      description: 'Implement robust authentication systems',
      level: 90
    },
    {
      icon: Eye,
      title: 'Threat Monitoring',
      description: 'Continuous security monitoring and alerting',
      level: 87
    },
    {
      icon: Terminal,
      title: 'Incident Response',
      description: 'Rapid response to security incidents',
      level: 85
    }
  ];

  const SkillCard = ({ icon: Icon, title, description, level, delay = 0 }) => (
    <div 
      className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start space-x-4">
        <div className="bg-blue-100 p-3 rounded-lg">
          <Icon className="h-6 w-6 text-blue-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 text-sm mb-4">{description}</p>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Proficiency</span>
              <span className="font-semibold text-blue-600">{level}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-600 to-cyan-600 h-2 rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${level}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Expertise & Skills
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Combining automation expertise with cybersecurity knowledge to deliver 
            secure, efficient, and scalable solutions for modern businesses.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <div className="flex items-center space-x-3 mb-8">
              <Zap className="h-8 w-8 text-yellow-500" />
              <h3 className="text-2xl font-bold text-gray-900">Automation</h3>
            </div>
            <div className="space-y-6">
              {automationSkills.map((skill, index) => (
                <SkillCard key={skill.title} {...skill} delay={index * 100} />
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center space-x-3 mb-8">
              <Shield className="h-8 w-8 text-red-600" />
              <h3 className="text-2xl font-bold text-gray-900">Cybersecurity</h3>
            </div>
            <div className="space-y-6">
              {securitySkills.map((skill, index) => (
                <SkillCard key={skill.title} {...skill} delay={index * 100 + 200} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;