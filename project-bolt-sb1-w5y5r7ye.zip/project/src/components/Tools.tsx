import React from 'react';
import { ExternalLink } from 'lucide-react';

const Tools = () => {
  const tools = [
    {
      name: 'Zapier',
      description: 'Advanced workflow automation and app integration platform',
      image: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=400',
      proficiency: 'Expert',
      color: 'from-orange-500 to-red-500'
    },
    {
      name: 'Make.com',
      description: 'Visual automation platform for complex multi-step workflows',
      image: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=400',
      proficiency: 'Expert',
      color: 'from-purple-500 to-pink-500'
    },
    {
      name: 'Notion',
      description: 'All-in-one workspace for documentation and project management',
      image: 'https://images.pexels.com/photos/7376/startup-photos.jpg?auto=compress&cs=tinysrgb&w=400',
      proficiency: 'Advanced',
      color: 'from-gray-700 to-gray-900'
    },
    {
      name: 'n8n',
      description: 'Open-source workflow automation for technical implementations',
      image: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=400',
      proficiency: 'Advanced',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      name: 'Airtable',
      description: 'Database automation and custom workflow builder',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
      proficiency: 'Expert',
      color: 'from-green-500 to-teal-500'
    },
    {
      name: 'Microsoft Power Automate',
      description: 'Enterprise-grade automation for Microsoft ecosystem',
      image: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=400',
      proficiency: 'Advanced',
      color: 'from-blue-600 to-indigo-600'
    }
  ];

  return (
    <section id="tools" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Tools & Platforms
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mastery of industry-leading automation platforms to deliver powerful, 
            scalable solutions tailored to your business needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tools.map((tool, index) => (
            <div 
              key={tool.name}
              className="group bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={tool.image}
                  alt={tool.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${tool.color} opacity-80`}></div>
                <div className="absolute top-4 right-4">
                  <ExternalLink className="h-5 w-5 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="absolute bottom-4 left-4">
                  <span className="bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {tool.proficiency}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{tool.name}</h3>
                <p className="text-gray-600 leading-relaxed">{tool.description}</p>
                
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className={`h-2 w-2 rounded-full ${
                          i < (tool.proficiency === 'Expert' ? 5 : 4) 
                            ? 'bg-yellow-400' 
                            : 'bg-gray-300'
                        }`}
                      ></div>
                    ))}
                  </div>
                  <button className="text-blue-600 hover:text-blue-700 font-semibold text-sm transition-colors">
                    Learn More →
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Tools;