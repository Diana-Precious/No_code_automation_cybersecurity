import React from 'react';
import { Shield, Zap, Eye, Settings, ArrowRight, CheckCircle } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Zap,
      title: 'Workflow Automation',
      description: 'Design and implement custom automation workflows to streamline your business processes.',
      price: 'Starting at $2,500',
      features: [
        'Process analysis and optimization',
        'Custom workflow design',
        'Platform integration',
        'Testing and deployment',
        '30-day support included'
      ],
      popular: false
    },
    {
      icon: Shield,
      title: 'Security Automation',
      description: 'Automated security monitoring, incident response, and compliance workflows.',
      price: 'Starting at $5,000',
      features: [
        'Security framework assessment',
        'Automated threat detection',
        'Incident response workflows',
        'Compliance reporting',
        'Ongoing security monitoring'
      ],
      popular: true
    },
    {
      icon: Eye,
      title: 'System Integration',
      description: 'Connect disparate systems and ensure seamless data flow across your organization.',
      price: 'Starting at $3,500',
      features: [
        'API integration planning',
        'Data mapping and transformation',
        'Real-time synchronization',
        'Error handling and logging',
        'Performance optimization'
      ],
      popular: false
    },
    {
      icon: Settings,
      title: 'Consultation & Training',
      description: 'Expert guidance on automation strategy and team training on no-code platforms.',
      price: '$150/hour',
      features: [
        'Automation strategy sessions',
        'Platform selection guidance',
        'Team training workshops',
        'Best practices documentation',
        'Ongoing support and mentoring'
      ],
      popular: false
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Services & Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive automation and security solutions tailored to your business needs. 
            From simple workflows to enterprise-grade security systems.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={service.title}
              className={`relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden ${
                service.popular ? 'ring-2 ring-blue-600' : ''
              }`}
            >
              {service.popular && (
                <div className="absolute top-0 left-0 right-0 bg-blue-600 text-white text-center py-2 text-sm font-semibold">
                  Most Popular
                </div>
              )}
              
              <div className={`p-8 ${service.popular ? 'pt-12' : ''}`}>
                <div className="text-center mb-6">
                  <div className="bg-blue-100 p-4 rounded-xl inline-block mb-4">
                    <service.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {service.description}
                  </p>
                </div>

                <div className="text-center mb-6">
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    {service.price}
                  </div>
                  <div className="text-sm text-gray-500">
                    {service.price.includes('hour') ? 'Flexible pricing' : 'Project-based'}
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
                  service.popular
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'border-2 border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600'
                }`}>
                  <span>Get Started</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Need a Custom Solution?
          </h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Every business is unique. Let's discuss your specific automation and security needs 
            to create a tailored solution that delivers maximum value.
          </p>
          <button className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
            Schedule Free Consultation
          </button>
        </div>
      </div>
    </section>
  );
};

export default Services;