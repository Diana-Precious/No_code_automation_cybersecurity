import React from 'react';
import { Shield, Zap, Mail, Phone, MapPin, Linkedin, Twitter, Github } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Shield className="h-8 w-8 text-blue-600" />
                <Zap className="h-4 w-4 text-cyan-500 absolute -top-1 -right-1" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                AutoSecure Pro
              </span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Bridging automation and cybersecurity to deliver secure, efficient, 
              and scalable solutions for modern businesses.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors">
                <Github className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Workflow Automation</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Security Automation</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">System Integration</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Consultation & Training</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Tools</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Zapier</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Make.com</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Notion</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">n8n</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Contact</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2 text-gray-400">
                <Mail className="h-4 w-4" />
                <span>hello@autosecurepro.com</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400">
                <Phone className="h-4 w-4" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400">
                <MapPin className="h-4 w-4" />
                <span>San Francisco, CA</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 AutoSecure Pro. All rights reserved. Built with security and automation in mind.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;